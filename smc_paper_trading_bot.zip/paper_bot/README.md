# SMC Paper Trading Bot — Binance live-цены + Vercel + Google Sheets

Бот раз в 1-5 минут проверяет реальную цену BTCUSDT (или другого символа) с
Binance, ищет сетап по упрощённой стратегии FVG_REBALANCE (самая устойчивая
из твоих бэктестов), открывает "бумажную" сделку и ведёт журнал в Google
Sheets. Реальных денег нигде не задействовано — только публичные цены с
Binance для реализма (без вопроса про спред демо-счёта).

**Важная честная оговорка:** это НЕ настоящий realtime (тикер за тиком).
Vercel — serverless-платформа: код "просыпается", делает свою работу за
секунды и "засыпает". Он не может держать вечный цикл. Поэтому проверка идёт
по расписанию (раз в 1-5 минут), а не непрерывно. Для инструментов вроде
15m-30m это практически не имеет значения. Для честного 1m-скальпинга
разница уже может быть заметна (можно поймать движение чуть позже, чем
"мгновенно").

---

## Шаг 1 — Создать Google Sheet (журнал сделок)

1. Создай новую таблицу на [sheets.google.com](https://sheets.google.com).
2. Переименуй 3 вкладки (внизу) именно так — регистр важен:
   - **Trades**
   - **State**
   - **Summary**
3. В **Trades**, строка 1 (заголовки):
   ```
   Date | Symbol | Direction | Reason | Entry | SL | TP | Qty | ExitPrice | ExitTime | PnL | PnL% | Status
   ```
4. В **State**, строка 1 (заголовки, для наглядности — код пишет в строку 2):
   ```
   Symbol | Direction | Entry | SL | PartialTP | FullTP | PartialTaken | TradeRow | Qty
   ```
5. В **Summary**, строка 1 (заголовки) и строка 2 (начальные значения):
   ```
   TotalTrades | Wins | Losses | TotalPnL | Balance
        0      |  0   |   0    |    0     |  1000
   ```
6. Скопируй ID таблицы из адресной строки браузера:
   `https://docs.google.com/spreadsheets/d/ЭТОТ_КУСОК_ID/edit` → это твой `GOOGLE_SHEET_ID`.

## Шаг 2 — Создать сервисный аккаунт Google (доступ к таблице из кода)

1. Зайди в [Google Cloud Console](https://console.cloud.google.com/) → создай новый проект (или используй существующий).
2. В меню слева: **APIs & Services → Library** → найди **Google Sheets API** → **Enable**.
3. **APIs & Services → Credentials → Create Credentials → Service Account**.
   - Имя любое, например `smc-bot`.
   - Роль можно не назначать (доступ дадим напрямую в таблице).
4. Открой созданный сервисный аккаунт → вкладка **Keys** → **Add Key → Create new key → JSON** → скачается файл.
5. Открой этот JSON-файл — тебе нужны два поля:
   - `client_email` → это `GOOGLE_SERVICE_ACCOUNT_EMAIL`
   - `private_key` → это `GOOGLE_PRIVATE_KEY` (вставь как есть, вместе с `-----BEGIN/END PRIVATE KEY-----`)
6. **Важно:** вернись в свой Google Sheet → кнопка **"Share" / "Настройки доступа"** → добавь email из `client_email` с правом **Editor**. Без этого шага бот не сможет писать в таблицу.

## Шаг 3 — Задеплоить на Vercel

1. Загрузи эту папку в свой GitHub-репозиторий (или используй `vercel` CLI напрямую без GitHub — см. ниже).
2. Зайди на [vercel.com](https://vercel.com) → **Add New → Project** → импортируй репозиторий.
3. В настройках проекта **Environment Variables** добавь все переменные из `.env.example` с реальными значениями:
   - `CRON_SECRET`
   - `SYMBOL`, `INTERVAL`, `INITIAL_BALANCE`, `RISK_PCT`
   - `GOOGLE_SHEET_ID`, `GOOGLE_SERVICE_ACCOUNT_EMAIL`, `GOOGLE_PRIVATE_KEY`
4. Нажми **Deploy**.

Либо через терминал, без GitHub:
```bash
npm i -g vercel
cd smc-paper-trading-bot
vercel login
vercel --prod
# затем добавь переменные окружения:
vercel env add CRON_SECRET production
vercel env add SYMBOL production
vercel env add INTERVAL production
vercel env add INITIAL_BALANCE production
vercel env add RISK_PCT production
vercel env add GOOGLE_SHEET_ID production
vercel env add GOOGLE_SERVICE_ACCOUNT_EMAIL production
vercel env add GOOGLE_PRIVATE_KEY production
vercel --prod   # передеплой, чтобы переменные подхватились
```

После деплоя у тебя будет URL вида `https://твой-проект.vercel.app`.

## Шаг 4 — Настроить расписание (раз в 1-5 минут)

**Бесплатный план Vercel (Hobby) разрешает cron только раз в СУТКИ** —
для реальной торговли этого мало. Два варианта:

### Вариант A (бесплатно) — внешний планировщик cron-job.org
1. Зайди на [cron-job.org](https://cron-job.org) → зарегистрируйся (бесплатно).
2. Создай новую задачу (Cronjob):
   - URL: `https://твой-проект.vercel.app/api/scan?secret=ТВОЙ_CRON_SECRET`
   - Периодичность: каждые 1-5 минут (доступно на бесплатном тарифе).
3. Готово — с этого момента твой Vercel-эндпоинт будет дёргаться по расписанию,
   даже с потушенным компьютером.

### Вариант B (платно, $20/мес) — встроенный Vercel Cron
Добавь в `vercel.json`:
```json
{
  "crons": [
    { "path": "/api/scan?secret=ТВОЙ_CRON_SECRET", "schedule": "*/5 * * * *" }
  ]
}
```
Это требует плана **Vercel Pro** — на Hobby такое расписание не задеплоится
(ошибка при деплое).

## Шаг 5 — Проверка

Открой в браузере (или Postman):
```
https://твой-проект.vercel.app/api/scan?secret=ТВОЙ_CRON_SECRET
```
Ответ типа `{"status":"no_signal","price":118234.5}` — значит всё работает,
просто сейчас нет сетапа. `{"status":"opened", ...}` — сделка открыта,
проверь вкладки **Trades** и **State** в таблице.

---

## Как это всё работает (коротко)

- `/api/scan` при каждом вызове:
  1. Смотрит **State** — есть ли открытая "бумажная" позиция.
  2. Если да — сверяет текущую цену со стопом/частичным/финальным тейком
     (схема: 20% объёма на +2R → перенос стопа в БУ → остаток закрывается
     на +4R либо по БУ) и обновляет **Trades**/**Summary**/**State**.
  3. Если позиции нет — ищет свежий Fair Value Gap и вход на его 50%-уровне
     (упрощённый порт стратегии FVG_REBALANCE), считает объём позиции от
     текущего баланса и риска на сделку, открывает сделку.
- Так как Vercel не хранит память между вызовами, **вся "память" бота —
  это вкладка State в Google Sheets**.

## Ограничения этой версии (что можно доработать)

- Реализована только 1 стратегия (FVG_REBALANCE) без HTF-контекста —
  самая устойчивая по твоим бэктестам, но не единственная.
- Финальный TP фиксированный (4R), а не структурный, как в полном
  Python-движке.
- Одна сделка одновременно (без учёта нескольких символов параллельно).
- Нет проверки минимального лота биржи — это просто виртуальный расчёт.

Если стратегия окажется рабочей на "бумаге" — можно постепенно добавить
остальные 4 стратегии из python-движка и/или несколько символов параллельно
(потребует расширения структуры State под мульти-позиции).
